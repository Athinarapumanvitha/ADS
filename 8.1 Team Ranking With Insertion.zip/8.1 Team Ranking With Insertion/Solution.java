import java.util.*;
import java.io.*;
class Cricketteam
{
    String name;
    int wins;
    int losses;
    int draws;
    Cricketteam(String name, int wins, int losses, int draws)
    {
        this.name=name;
        this.wins=wins;
        this.losses=losses;
        this.draws=draws;
    }
}
class WinsComparator implements Comparator
{
    public  int  compare(Object c3,Object c4)
    {
        Cricketteam c1=(Cricketteam)c3;
        Cricketteam c2=(Cricketteam)c4;
        if(c1.wins==c2.wins)
        {
            if(c1.losses==c2.losses)
            {
                if(c1.draws==c2.draws)
                    return 0;
                else if(c1.draws<c2.draws)
                    return 1;
                else
                    return -1;
                
            }
            else if(c1.losses>c2.losses)
                return 1;
            else
                return -1;
            
            
        }
        else if(c1.wins<c2.wins)
            return 1;
        else
            return -1;
    }
}
class Main3
{
    public static void main(String args[])
    {
        ArrayList<Cricketteam> al=new ArrayList<Cricketteam>();
        al.add(new Cricketteam("England",4,2,3));
        
        al.add(new Cricketteam("India",5,2,4));
        al.add(new Cricketteam("Australia",6,2,3));
        al.add(new Cricketteam("SouthAfrica",5,3,4));
        
        al.add(new Cricketteam("Bangladesh",3,4,2));
        
        al.add(new Cricketteam("Zimbabwe",3,4,6));
        
        al.add(new Cricketteam("Ireland",3,4,1));
        Collections.sort(al,new WinsComparator());
        for(Cricketteam t:al)
        {
            System.out.println(t.name+","+t.wins+","+t.losses+","+t.draws);
        }
    }
}

